
const meuModulo = require('./meu_modulo')

const soma = meuModulo.soma;


soma(2,3)
soma(7,3)
soma(2,8)
soma(2,13)