module.exports = {
     soma(a, b){
    console.log(a + b)
}
}