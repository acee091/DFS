function a() {
    console.log('Executando a função a()')
}

function b() {
    console.log('Executando a função b()')
}

function c() {
    console.log('Executando a função c()')

    b()
    a()
}

c()
