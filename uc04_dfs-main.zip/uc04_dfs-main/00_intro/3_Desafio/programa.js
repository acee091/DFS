console.log('Estou aqui no senac')

const a = 5;
const b = 10;

console.log(a+b)
console.log(`A soma entre a=${a}  e b=${b} é ${a + b}`); //interpolação de string
