/*====
3 - Tarefa 1 
====
0. Crie um pasta  chamada "03_desafio" e entre nessa pasta.
1. Crie um arquivo chamado "programa.js" e digite  "Estou aqui no Senac"
2. Escreva um programa que tenha as variaveis a =  10 e b= 5 ,e exiba a soma no console através do node
3. Execute o comando abaixo no terminal:
    const a = 10;
    const b = 5;*/