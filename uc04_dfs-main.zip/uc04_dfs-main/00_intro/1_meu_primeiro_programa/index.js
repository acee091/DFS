console.log("Hello World Node!")
console.log("Fala Jovem!")
console.log("Estamos começando os estudo de Nodejs!")