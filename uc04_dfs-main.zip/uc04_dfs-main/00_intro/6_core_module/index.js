const path = require("path")

const extension = path.extname("arquivo.pdf")

console.log(`A extensão do arquivo é ${extension}`)  // A extensão do arquivo é .docx