const fs = require("fs")
console.log("Início")
fs.writeFileSync("arquivo.txt", "Oi jovem!")
console.log("Fim")

