const x = 10
const y = "Rodolfo"
const z = "Programador"

console.log(x, y , z)

console.count("O valor de x é " + x + "-> contagem")
console.count("O valor de x é " + x + "-> contagem")
console.count("O valor de x é " + x + "-> contagem")
console.count("O valor de x é " + x + "-> contagem")
console.count("O valor de x é " + y + "-> contagem")
console.count("O valor de x é " + y + "-> contagem")
console.count("O valor de x é " + y + "-> contagem")
console.count("O valor de x é " + z + "-> contagem")
console.count("O valor de x é " + z + "-> contagem")
console.count("O valor de x é " + z + "-> contagem")


setTimeout(() => {
    console.clear()
}, 2000)